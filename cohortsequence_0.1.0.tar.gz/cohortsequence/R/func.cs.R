#' Cohort sequence design
#'
#' Simulate responses the cohort sequence design based on a toxicity profile for different dose levels. When the number of DLTS is b_j+1, the rest of the cohort will not be treated at the current dose and start de-escalation.
#' @param tox_prob vector of toxicity probabilities
#' @param nj vector of cohort sizes
#' @param seed randomization seed
#' @param verbose logical; if TRUE, print some details at each dose
#' @param a First argument for the beta prior distribution of p_i
#' @param b Second argument for the beta prior distribution of p_i
#' @param theta safety threshold
#' @return list including results at each dose level(res.data), along with the estimated MTD (MTD), number of patients treated at MTD (n.MTD), total number of patients (n.total), overall toxicity (prob.tox), maximum number of dose levels examined (n.cohort).
#' @export
#compute the upper bound using quantiles from the posterior of p_i

func.cs = function(tox_prob,nj=c(1,3,5,8,10),seed=123,verbose=F,
                   a=1,b=4,theta = 0.5){

  find.dose = function(CBs){
    # find the dose/location i S.T. i = min[d:conf. bound > threshold]
    if(CBs[length(CBs)]<=0.1){
      ans = length(CBs)
    }
    else{
      ans = min(which(CBs > 0.1))
    }
    return(ans)
  }

  nj.max = max(nj)
  n.ind = 1 # cohort size index
  stop = 0
  res.data = matrix(0,nrow=length(tox_prob),ncol=4) # additional col for UCB
  colnames(res.data) = c('dose','n','x','f')
  res.data[,1]=1:length(tox_prob)
  set.seed(seed)
  for(i in 1:length(tox_prob)){
    n.ind=min(n.ind,length(nj)) # in case ind goes too high
    cur.n = nj[n.ind]
    toxicity = rbinom(cur.n,1,tox_prob[i])
    res.data[i,2] = cur.n
    n.DLT = sum(toxicity)
    res.data[i,3] = n.DLT
    res.data[i,4] = comp.f(n=cur.n,x=n.DLT,theta=theta,a=a,b=b)

    if(verbose){print(paste('dose',i,',# DLT =',n.DLT,', N =',cur.n,',f=',res.data[i,4]))}
    if(res.data[i,4]<0.1 & i < length(tox_prob)){
      if(verbose){print('escalate')}
    }
    else if( comp.f(n=cur.n,x=n.DLT-1,a=a,b=b,theta=theta)<0.1|
             (res.data[i,4]<= 0.1 & i == length(tox_prob))){
      # enroll more at current dose
      n.ind = n.ind+1
      cur.n = min(nj.max,nj[n.ind],na.rm=T)
      if(i==length(tox_prob)){cur.n=nj.max}
      toxicity = c(toxicity,rbinom(cur.n-res.data[i,2],1,tox_prob[i]))
      n.DLT = sum(toxicity)
      res.data[i,2] = cur.n
      res.data[i,3] = n.DLT
      res.data[i,4] = comp.f(n=cur.n,x=n.DLT,a=a,b=b,theta=theta)
      if(verbose){
        print(paste(c('new DLT: ',n.DLT,', N = ',cur.n)))
        print(c('Dose',i,paste(toxicity,sep='')))
      }
    }
    if(res.data[i,4]>0.1){ # de-escalate
      if(verbose){print('de-escalate')}
      # stop after too many DLT
      res.data[i,3] = find.dose(comp.f(n=cur.n,x=1:n.DLT,a=a,b=b,theta=theta))
      res.data[i,2] = min(which(cumsum(toxicity)==res.data[i,3]))
      res.data[i,4] = comp.f(n=res.data[i,2],x=res.data[i,3],a=a,b=b,theta=theta)
      while(stop == 0 & i > 1){
        i = i-1
        if(res.data[i,2]==nj.max){ # lower dose is safe and no need for more patients
          stop = 1
        }else{
          prev.DLT = res.data[i,3]
          prev.n = res.data[i,2]
          toxicity.new = rbinom(nj.max-prev.n,1,tox_prob[i])
          n.DLT = prev.DLT+sum(toxicity.new)
          if(verbose){print(c('Dose',i,'new resp:',paste(toxicity.new,sep='')))}
          if(n.DLT == 0){
            res.data[i,3] = 0
          }else{
            res.data[i,3] = find.dose(comp.f(n=nj.max,x=1:n.DLT,a=a,b=b,theta=theta))
          }
          res.data[i,4] = comp.f(n=nj.max,x=res.data[i,3],a=a,b=b,theta=theta)

          if(res.data[i,4]<= 0.1){ # all subj. enrolled
            res.data[i,2] = nj.max
            stop = 1
          }else{
            res.data[i,2] = prev.n + min(which(cumsum(toxicity.new)==res.data[i,3]-prev.DLT))
          }
          res.data[i,4] = comp.f(n=res.data[i,2],x=res.data[i,3],a=a,b=b,theta=theta)
          if(verbose){print(paste(c('new DLT: ',res.data[i,3], 'N = ',res.data[i,2])))}
        }
      }
      if(i == 1 & stop == 0){ # lowest dose is unsafe
        if(verbose){print('Lowest dose is unsafe')}
        return(list('res.data'=res.data,'MTD'=0,'n.MTD'=0,
                    'n.total'=sum(res.data[,2]),'prob.tox'=sum(res.data[,3])/sum(res.data[,2]),
                    'n.cohort'=sum(res.data[,2]!=0)))
      }
      else{
        if(verbose){print(c('recommend dose level',i))}
        return(list('res.data'=res.data,'MTD'=i,'n.MTD'=res.data[i,2],
                    'n.total'=sum(res.data[,2]),'prob.tox'=sum(res.data[,3])/sum(res.data[,2]),
                    'n.cohort'=sum(res.data[,2]!=0)))
      }
    } # end of de-escalate
    if(i == length(tox_prob) & res.data[i,2]==nj.max & res.data[i,4]<=0.1){ # highest dose
      if(verbose){print(paste('reached max, recommend dose level',i))}

      return(list('res.data'=res.data,'MTD'=i,'n.MTD'=res.data[i,2],
                  'n.total'=sum(res.data[,2]),'prob.tox'=sum(res.data[,3])/sum(res.data[,2]),
                  'n.cohort'=sum(res.data[,2]!=0)))
    }
  } # close i
} # end function
