#' Find the cohort size
#'
#' Find the cohort size n_j based on the critical value b_j, safety threshold theta, and prior distribution for toxicity probability p_i (beta(a,b)).
#' @param bj the critical value for the number of DLTs
#' @param theta safety threshold
#' @param a First argument for the beta prior distribution of p_i
#' @param b Second argument for the beta prior distribution of p_i
#' @return The cohort size n_j
#' @export
find.cohort = function(bj,theta=0.5,a=1,b=4){
  tmp.f = function(tmp.bj){
    UBs = sapply(tmp.bj:(tmp.bj*20),comp.f,x=tmp.bj,theta = theta,a=a,b=b)

    safe.UBs = sapply(tmp.bj:(tmp.bj*20),comp.f,x=tmp.bj-1,theta=theta,a=a,b=b)
    res = (safe.UBs <= 0.1) + (UBs > .1)

    if(max(UBs)< 0.1)
      return("theta might be too high")

    ans = min(which(res==2))+(tmp.bj-1)
    if(ans != Inf)
      return(ans)
    else
      return(NA)
  }
  return(sapply(bj,tmp.f))
}
