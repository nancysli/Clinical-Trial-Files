#' Compute the f function for cohort sequence design
#'
#' The toxicity probabilities follows a prior distribution of beta(a,b). We calculate the posterior probability P(p_i > theta|X_i,N_i ) based on observed DLT X_i and cohort size N_i.
#' @param n The cohort size (scalar)
#' @param x Vector of Observed number of DLTs
#' @param theta Safety threshold
#' @param a First argument for the beta prior distribution of p_i
#' @param b Second argument for the beta prior distribution of p_i
#' @return A value or a vector ef values for the posterior probability of p_i greater than theta. If the returned value is less than 0.1, it implies the dose is safe. The smallest X_i that leads to the result above 0.1 implies uncertainty about toxicity and requires additional patiets treated at the dose. A value larger than 0.1 implies the dose is too toxic.
#' @export
comp.f = function(n,x,theta=.5,a=1,b=4){
  if(n < max(x))
    return('Error: n >= x')
  ans = rep(NA,length(x))
  for(i in 1:length(ans)){
    ans[i] = pbeta(theta,a+x[i],b+n-x[i],lower.tail = F)
  }
  return(ans)
}
