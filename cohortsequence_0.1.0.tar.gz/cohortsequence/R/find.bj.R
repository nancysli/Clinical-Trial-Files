#' Identify the critical value b_j for cohort size n_j
#'
#' Compute f(X_i) for all possible numbers of DLTs for cohort size n_j, where the toxicity probabilities follw a prior distribution of beta(a,b), and the safety threshold is theta. Then identify the critical value b_j that determines the escalation/expansion/de-escalation decision if observed X_i is less than/equals/is above b_j
#' @param n The cohort size (vector or scalar)
#' @param theta Safety threshold
#' @param a First argument for the beta prior distribution of p_i
#' @param b Second argument for the beta prior distribution of p_i
#' @return The critical value bj for cohort size n.
#' @export
find.bj = function(n,theta=0.5,a=1,b=4){
  ans = rep(NA,length(n))
  tmp.f = function(n.tmp){
    fs = comp.f(n=n.tmp,x=0:n.tmp,theta=theta,a=a,b=b)
    if((fs[length(fs)]) <= 0.1){
      ans = length(fs) - 1
    }else{
      ans = min(which(fs > 0.1))-1
    }
    return(ans)
  }
  return(sapply(n,tmp.f))
}
